from locust import HttpLocust, TaskSet, task


class UserBehavior(TaskSet):

    def on_start(self):
        """ on_start is called when a Locust start before any task is scheduled """
        self.login()

    def login(self):
        self.client.post("/auth/login", {"email":"testingwtb@126.com","password": "111111"})
    
    @task
    def index_page(self):
        with self.client.get("/", catch_response=True) as response:
            if b"testingwtb" not in response.content:
                response.failure("Got wrong response")


class WebsiteUser(HttpLocust):
    task_set = UserBehavior
    min_wait = 3000
    max_wait = 6000
